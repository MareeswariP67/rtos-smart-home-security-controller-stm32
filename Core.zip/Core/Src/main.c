/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * RTOS Smart Home Security Controller (LIGHTWEIGHT VERSION)
  * Board : STM32F030R8
  * UART  : USART1 @ 38400
  * RAM Optimized
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include "cmsis_os.h"
#include <stdio.h>
#include <string.h>

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim3;
UART_HandleTypeDef huart1;

/* RTOS Task Handles ---------------------------------------------------------*/
osThreadId_t pirTaskHandle;
osThreadId_t ultraTaskHandle;
osThreadId_t alarmTaskHandle;
osThreadId_t statusTaskHandle;

/* RTOS Task Attributes (Reduced RAM) ---------------------------------------*/
const osThreadAttr_t pirTask_attributes = {
  .name = "pirTask",
  .stack_size = 48 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

const osThreadAttr_t ultraTask_attributes = {
  .name = "ultraTask",
  .stack_size = 48 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

const osThreadAttr_t alarmTask_attributes = {
  .name = "alarmTask",
  .stack_size = 48 * 4,
  .priority = (osPriority_t) osPriorityHigh,
};

const osThreadAttr_t statusTask_attributes = {
  .name = "statusTask",
  .stack_size = 48 * 4,
  .priority = (osPriority_t) osPriorityLow,
};

/* Global Variables ----------------------------------------------------------*/
volatile uint8_t motionDetected = 0;
volatile uint8_t intrusionDetected = 0;
volatile float distance_cm = 0;

/* Function Prototypes -------------------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART1_UART_Init(void);

void StartPIRTask(void *argument);
void StartUltraTask(void *argument);
void StartAlarmTask(void *argument);
void StartStatusTask(void *argument);

void delay_us(uint16_t us);
float Read_Distance(void);
void SetRGB(uint8_t r, uint8_t g, uint8_t b);
void Debug_Print(char *msg);

/* ========================================================================== */

int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();

  HAL_TIM_Base_Start(&htim3);

  osKernelInitialize();

  pirTaskHandle    = osThreadNew(StartPIRTask, NULL, &pirTask_attributes);
  ultraTaskHandle  = osThreadNew(StartUltraTask, NULL, &ultraTask_attributes);
  alarmTaskHandle  = osThreadNew(StartAlarmTask, NULL, &alarmTask_attributes);
  statusTaskHandle = osThreadNew(StartStatusTask, NULL, &statusTask_attributes);

  osKernelStart();

  while (1)
  {
  }
}

/* ========================================================================== */
/* TASK 1 : PIR Detection                                                     */
/* ========================================================================== */
void StartPIRTask(void *argument)
{
  for(;;)
  {
    motionDetected = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0);
    osDelay(100);
  }
}

/* ========================================================================== */
/* TASK 2 : Ultrasonic Detection                                              */
/* ========================================================================== */
void StartUltraTask(void *argument)
{
  for(;;)
  {
    distance_cm = Read_Distance();

    if(distance_cm > 0 && distance_cm < 20)
      intrusionDetected = 1;
    else
      intrusionDetected = 0;

    osDelay(200);
  }
}

/* ========================================================================== */
/* TASK 3 : Alarm Task                                                        */
/* ========================================================================== */
void StartAlarmTask(void *argument)
{
  for(;;)
  {
    if(motionDetected && intrusionDetected)
    {
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_SET); // Buzzer
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET); // Relay
    }
    else
    {
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
    }

    osDelay(50);
  }
}

/* ========================================================================== */
/* TASK 4 : RGB + Debug Status                                                */
/* ========================================================================== */
void StartStatusTask(void *argument)
{
  char msg[40];

  for(;;)
  {
    if(motionDetected && intrusionDetected)
      SetRGB(1,0,0);   // Red
    else if(motionDetected)
      SetRGB(1,1,0);   // Yellow
    else
      SetRGB(0,1,0);   // Green

    sprintf(msg, "M:%d D:%d I:%d\r\n",
            motionDetected, (int)distance_cm, intrusionDetected);

    Debug_Print(msg);

    osDelay(1000);
  }
}

/* ========================================================================== */
/* Helper Functions                                                           */
/* ========================================================================== */

void delay_us(uint16_t us)
{
  __HAL_TIM_SET_COUNTER(&htim3, 0);
  while(__HAL_TIM_GET_COUNTER(&htim3) < us);
}

float Read_Distance(void)
{
  uint32_t time = 0;
  uint32_t timeout = 30000;

  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
  delay_us(2);

  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
  delay_us(10);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);

  while(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2) == GPIO_PIN_RESET)
    if(--timeout == 0) return -1;

  __HAL_TIM_SET_COUNTER(&htim3, 0);

  timeout = 30000;
  while(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2) == GPIO_PIN_SET)
    if(--timeout == 0) return -1;

  time = __HAL_TIM_GET_COUNTER(&htim3);

  return (float)time * 0.0343f / 2.0f;
}

void SetRGB(uint8_t r, uint8_t g, uint8_t b)
{
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, r ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOF, GPIO_PIN_4, g ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOF, GPIO_PIN_5, b ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void Debug_Print(char *msg)
{
  HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 100);
}

/* ========================================================================== */
/* Peripheral Config                                                          */
/* ========================================================================== */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL12;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK |
                                RCC_CLOCKTYPE_SYSCLK |
                                RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1);

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit);
}

static void MX_TIM3_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 48 - 1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  HAL_TIM_Base_Init(&htim3);

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig);

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig);
}

static void MX_USART1_UART_Init(void)
{
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 38400;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  HAL_UART_Init(&huart1);
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();

  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOF, GPIO_PIN_4|GPIO_PIN_5, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);
}

void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}
